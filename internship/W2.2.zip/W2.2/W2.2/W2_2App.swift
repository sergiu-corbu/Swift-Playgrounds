//
//  W2_2App.swift
//  W2.2
//
//  Created by Sergiu Corbu on 3/23/21.
//

import SwiftUI

@main
struct W2_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
